# Eksempelspørgsmål til RAG-data

## IT (it.txt)
- Hvordan nulstiller jeg min adgangskode?
- Hvornår skal jeg bruge VPN?
- Hvad gør jeg ved MFA-problemer?

## HR (hr.txt)
- Hvornår skal jeg melde sygdom?
- Hvor meget hjemmearbejde er tilladt?
- Hvad er reglen for overtid?

## Projektproces (proces.txt)
- Hvordan starter vi et nyt projekt?
- Hvordan håndterer vi ændringsønsker?
- Hvornår skal vi lave post-mortem?