import os
from pathlib import Path
from typing import List, Tuple

from openai import OpenAI
from dotenv import load_dotenv


DOCS_DIR = Path("rag")
EMBED_MODEL = os.getenv("OPENAI_EMBED_MODEL", "text-embedding-3-small")
CHAT_MODEL = os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini")
TOP_K = int(os.getenv("RAG_TOP_K", "5"))
MIN_SIM = float(os.getenv("RAG_MIN_SIM", "0.25"))


def read_text_files() -> List[Tuple[str, str]]:
    files = []
    if not DOCS_DIR.exists():
        return files
    for path in DOCS_DIR.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".txt", ".md"}:
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            if text.strip():
                files.append((str(path), text))
    return files


def chunk_text(text: str, max_chars: int = 1200, overlap: int = 200) -> List[str]:
    chunks = []
    start = 0
    n = len(text)
    while start < n:
        end = min(start + max_chars, n)
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= n:
            break
        next_start = end - overlap
        if next_start <= start:
            # Prevent infinite loop when text is shorter than overlap.
            break
        start = max(next_start, 0)
    return chunks


def embed_texts(client: OpenAI, texts: List[str]) -> List[List[float]]:
    embeddings = []
    batch_size = 64
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        resp = client.embeddings.create(model=EMBED_MODEL, input=batch)
        for item in resp.data:
            embeddings.append(item.embedding)
    return embeddings


def dot(a: List[float], b: List[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def build_index(client: OpenAI):
    docs = read_text_files()
    chunks = []
    sources = []
    for path, text in docs:
        for chunk in chunk_text(text):
            chunks.append(chunk)
            sources.append(path)
    if not chunks:
        return [], [], []
    vectors = embed_texts(client, chunks)
    return chunks, sources, vectors


def retrieve(client: OpenAI, query: str, chunks, sources, vectors):
    if not chunks:
        return []
    q_vec = embed_texts(client, [query])[0]
    scored = [(dot(q_vec, v), i) for i, v in enumerate(vectors)]
    scored.sort(reverse=True)
    top = []
    for score, idx in scored[:TOP_K]:
        if score < MIN_SIM:
            continue
        top.append((score, chunks[idx], sources[idx]))
    return top


def answer_question(client: OpenAI, question: str, contexts):
    if not contexts:
        return "det ved jeg ikke"
    context_text = "\n\n".join(
        f"[KILDE: {src}]\n{chunk}" for _, chunk, src in contexts
    )
    system = (
        "Du er en intern RAG-chatbot. Du maa KUN svare ud fra KILDE-teksterne. "
        "Hvis svaret ikke findes i KILDE-teksterne, skal du bruge din generelle viden, men fortæl det til brugeren "
        "Skriv kort og praecist paa dansk."
    )
    user = f"KILDE-TEKSTER:\n{context_text}\n\nSPOERGSMAL: {question}"
    resp = client.chat.completions.create(
        model=CHAT_MODEL,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        temperature=0,
    )
    return resp.choices[0].message.content.strip()


def main():
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("OPENAI_API_KEY mangler i environment.")
        return
    client = OpenAI(api_key=api_key)
    chunks, sources, vectors = build_index(client)
    if not chunks:
        print("Ingen dokumenter fundet i rag/ (understotter .txt og .md).")
        print("Botten vil altid svare: det ved jeg ikke")

    print("Intern RAG-chatbot. Skriv 'exit' for at stoppe.")
    while True:
        try:
            question = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not question:
            continue
        if question.lower() in {"exit", "quit"}:
            break
        contexts = retrieve(client, question, chunks, sources, vectors)
        answer = answer_question(client, question, contexts)
        print(answer)


if __name__ == "__main__":
    main()
